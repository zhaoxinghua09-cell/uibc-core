uibc-conformance 0.7.0 — 200 cases, frozen

Contents: manifest.json (200 cases, per-case directory digest), expected.json (the
second carrier of the same truth; run.py refuses to start if the two disagree),
cases/ (20 base packages + 142 mutations + 38 accept cases with nonce-distinct
evidence roots: 133 distinct roots in total), run.py (the runner; default scoring is
refusal-only, --strict-verdict compares verdicts, --require-all-checks demands that
a refusal name every expected check), uibc_core.pyz (the reference verifier, so this
archive can be run on a machine that has no uibc-core installed).

Run it:
  python run.py --strict-verdict --require-all-checks --json

Measured 2026-11-27 on this archive: reference implementation 200/200 (100%); a
blanket 'FAIL + [S4]' script 27/200 (13.5%); 'FAIL + [S12]' 19/200 (9.5%). All of
those are the same operator's dry runs, not third-party reruns.

Append-only: SHA256SUMS pins every published byte. Changing a case, a manifest
entry or the runner changes a checksum; a release does not edit a published line,
it publishes a new archive.
