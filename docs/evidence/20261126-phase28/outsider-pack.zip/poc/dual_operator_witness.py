# -*- coding: utf-8 -*-
"""dual_operator_witness.py — 两个独立见证运营方的真跨进程共签。

为什么需要它：v0.8 的 witness 一直是"同一进程里的演示密钥"。竞品对照里
"第三方见证运营"被记为落后项，而落后项不该靠叙事解释。这里把见证方拆成
**独立进程 + 独立密钥目录 + 独立工作目录**，验证方只持有公钥集，k-of-n 判定
在无共享状态的前提下完成；同时把六类伪造逐个打成 FAIL。

它不是"已接入第三方"：两个运营方都跑在本机同一台机器上，仍是模拟。

用法（本仓）：
    python poc/dual_operator_witness.py run --src proto/src \
        --package src-snapshot/conformance/cases/06-a-package-sealed-with-ed25519 --out out
用法（外人复跑包，apply 补丁之后）：
    python poc/dual_operator_witness.py run --src ./src --package poc/v06-pkg --out out
"""
import argparse, base64, hashlib, json, os, subprocess, sys, datetime


def _now():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _ensure_seed(keydir):
    os.makedirs(keydir, exist_ok=True)
    p = os.path.join(keydir, "witness.seed.hex")
    if os.path.exists(p):
        with open(p, encoding="ascii") as f:
            return bytes.fromhex(f.read().strip()), p
    seed = os.urandom(32)
    with open(p, "w", encoding="ascii", newline="\n") as f:
        f.write(seed.hex())
    return seed, p


def _load_mods(src):
    src = os.path.abspath(src)
    if src not in sys.path:
        sys.path.insert(0, src)
    from uibc_core import signing, witness, witness_registry  # noqa: E402
    return signing, witness, witness_registry


def cmd_cosign(a):
    _, witness, _ = _load_mods(a.src)
    seed, _ = _ensure_seed(a.keydir)
    cos = witness.cosign(a.checkpoint, seed, a.id)
    cos["_pid"] = os.getpid()
    cos["_cwd"] = os.getcwd()
    cos["_keydir"] = os.path.abspath(a.keydir)
    cos["_at"] = _now()
    print(json.dumps(cos, ensure_ascii=False))
    return 0


def _run_child(operator, root, checkpoint, src):
    keydir = os.path.join(root, "operators", operator)
    _ensure_seed(keydir)
    cp = subprocess.run(
        [sys.executable, os.path.abspath(__file__), "cosign",
         "--src", os.path.abspath(src), "--keydir", keydir,
         "--id", operator, "--checkpoint", checkpoint],
        capture_output=True, text=True, encoding="utf-8", timeout=120,
    )
    if cp.returncode != 0:
        raise RuntimeError("child %s failed: %s" % (operator, cp.stderr[-400:]))
    return json.loads(cp.stdout.strip().splitlines()[-1]), os.path.abspath(keydir)


def main_run(a):
    signing, witness, witness_registry = _load_mods(a.src)
    root = os.path.abspath(a.out)
    pkg = os.path.abspath(a.package)

    with open(os.path.join(pkg, "manifest.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    with open(os.path.join(pkg, "signatures", "seal.json"), encoding="utf-8") as f:
        seal_pub = json.load(f)["public_key"]
    head = manifest["checkpoint_head"]

    cos_a, kd_a = _run_child("wt-a", root, head, a.src)
    cos_b, kd_b = _run_child("wt-b", root, head, a.src)
    seed_c, _ = _ensure_seed(os.path.join(root, "operators", "wt-c"))
    pub_c = base64.b64encode(signing.ed_public_key(seed_c)).decode("ascii")

    policy = {
        "schema": "uibc-witness-policy/0.1",
        "name": "dual-operator-2of3",
        "quorum": 2,
        "witnesses": [
            {"id": "wt-a", "public_key": cos_a["public_key"], "operator": "operator-A"},
            {"id": "wt-b", "public_key": cos_b["public_key"], "operator": "operator-B"},
            {"id": "wt-c", "public_key": pub_c, "operator": "operator-C (listed, not signing)"},
        ],
    }
    witness_registry.load_policy(policy)
    ok, detail = witness_registry.verify_quorum(policy, [cos_a, cos_b], head, seal_pub)

    def q(coss):
        return witness_registry.verify_quorum(policy, coss, head, seal_pub)[0]

    neg = {}
    neg["only_one_cosignature"] = q([cos_a])
    neg["duplicate_same_witness"] = q([cos_a, dict(cos_a)])

    tampered = dict(cos_b)
    sb = bytearray(base64.b64decode(tampered["signature"]))
    sb[0] ^= 0x01
    tampered["signature"] = base64.b64encode(bytes(sb)).decode("ascii")
    neg["tampered_cosignature"] = q([cos_a, tampered])

    neg["key_not_in_policy"] = q([cos_a, witness.cosign(head, os.urandom(32), "wt-x")])

    other_head = "sha256:" + hashlib.sha256(b"another-checkpoint").hexdigest()
    moved = witness.cosign(other_head, _ensure_seed(os.path.join(root, "operators", "wt-b"))[0], "wt-b")
    neg["cosignature_for_other_checkpoint"] = q([cos_a, moved])

    forged = json.loads(json.dumps(policy))
    forged["witnesses"][1]["public_key"] = seal_pub
    sealish = witness.cosign(head, os.urandom(32), "wt-b")
    sealish["public_key"] = seal_pub
    neg["witness_is_the_seal_key"] = witness_registry.verify_quorum(
        forged, [cos_a, sealish], head, seal_pub)[0]

    ids = {"a": {"pid": cos_a["_pid"], "keydir": kd_a, "pub_fp": cos_a["public_key"][:16]},
           "b": {"pid": cos_b["_pid"], "keydir": kd_b, "pub_fp": cos_b["public_key"][:16]}}
    distinct = (ids["a"]["pid"] != ids["b"]["pid"]
                and ids["a"]["keydir"] != ids["b"]["keydir"]
                and ids["a"]["pub_fp"] != ids["b"]["pub_fp"])

    rec = {
        "schema": "uibc-dual-operator-witness/0.1",
        "at": _now(),
        "checkpoint_head": head,
        "src": os.path.abspath(a.src),
        "package": pkg,
        "policy": policy,
        "positive": {"quorum_2of3_with_two_signers": ok, "detail": detail},
        "independence": {
            "separate_processes": ids["a"]["pid"] != ids["b"]["pid"],
            "separate_key_dirs": ids["a"]["keydir"] != ids["b"]["keydir"],
            "separate_public_keys": ids["a"]["pub_fp"] != ids["b"]["pub_fp"],
            "all_three": distinct,
            "operators": ids,
        },
        "negative": neg,
        "negative_all_refused": all(v is False for v in neg.values()),
        "honest_caveat": [
            "两个运营方跑在本机同一台机器上，是模拟，不是接入第三方",
            "第三家 wt-c 只列入策略、不出签，用于证明 k-of-n 不必全签",
            "封条私钥在本机不以明文存在，'见证=封条'一条只验证公钥相等即拒的规则分支",
        ],
        "verdict": "PASS" if (ok and distinct and all(v is False for v in neg.values())) else "FAIL",
    }
    os.makedirs(root, exist_ok=True)
    out = os.path.join(root, "dual_operator_witness.json")
    with open(out, "w", encoding="utf-8", newline="\n") as f:
        json.dump(rec, f, ensure_ascii=False, indent=2)
        f.write("\n")

    print("verdict:", rec["verdict"])
    print("  positive 2-of-3:", ok, "| valid:", detail["valid"], "| quorum:", detail["quorum"])
    print("  independence:", rec["independence"]["all_three"],
          "(pid %s vs %s)" % (ids["a"]["pid"], ids["b"]["pid"]))
    for k, v in neg.items():
        print("  negative %-36s -> %s" % (k, "PASS(refused)" if v is False else "FAIL(accepted!)"))
    print("  written:", out)
    return 0 if rec["verdict"] == "PASS" else 1


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--src", required=True, help="含 uibc_core 的源码根（本仓 proto/src，复跑包为 ./src）")
    r.add_argument("--package", required=True, help="样本包目录（需含 manifest.json 与 signatures/seal.json）")
    r.add_argument("--out", required=True, help="输出目录")
    r.set_defaults(func=main_run)
    c = sub.add_parser("cosign")
    c.add_argument("--src", required=True)
    c.add_argument("--keydir", required=True)
    c.add_argument("--id", required=True)
    c.add_argument("--checkpoint", required=True)
    c.set_defaults(func=cmd_cosign)
    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
