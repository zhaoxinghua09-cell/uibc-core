# 外人复跑包 — UIBC 隐私披露层（v0.6 候选）

本包**不含任何 UIBC 仓库副本**，只含补丁、披露包驱动、一个样本包、一个台子场景组、与预期输出。
目的：让一个**没参与过这个项目的人**，在一台干净机器上，用一条条命令自行判断下面三条命题是否成立。

## 三条可证伪命题

1. 补丁能在干净仓库上**干净应用**（`git apply --check` 返回 0）。
2. `evidence_root` 能为 Merkle 算法，且**旧包判定不变**（legacy 根值不变、36 例套件不回归）。
3. 披露包 0.6 能做到：**该过的过**（基线 PASS、篡改全拒），且**只凭证明**验证日志一致性（不需要交出历史条目）。

## 环境

- Python **3.10+**（本机实测 3.13.18）；除标准库外**不需要**任何第三方包（不需要 jsonschema，验证脚本不读 schema）
- git（只在第 0 步用）
- 平台：Windows / Linux / macOS 均可（路径分隔符按你的平台改）

## 步骤

### 0. 拿一份干净仓库

```bash
git clone https://github.com/zhaoxinghua09-cell/uibc-core.git uibc-core
cd uibc-core
git rev-parse --short HEAD           # 期望 7885af9（或其后代）
```

### 1. 补丁能否干净应用（命题 1）

```bash
git apply --check /path/to/patch/v06_v07_v08_v09_privacy.patch; echo "exit=$?"
# 期望 exit=0（只检查，不落盘）
git apply /path/to/patch/v06_v07_v08_v09_privacy.patch
```
> 若 exit≠0：多半是仓库已前进导致上下文漂移，请记录 `git rev-parse HEAD` 与报错原文，**不要**用 `--3way` 强合后再声称通过。

### 2. 建一个"隐私实验根"（只为跑披露包驱动）

驱动脚本会从 `<ROOT>/proto/src` 取被测代码，所以：

```bash
mkdir -p /path/to/root/proto
cp -r uibc-core /path/to/root/proto/src
cp -r /path/to/kit/poc /path/to/root/poc
export UIBC_PRIVACY_ROOT=/path/to/root        # PowerShell: $env:UIBC_PRIVACY_ROOT="..."
export UIBC_SUBJECT=/path/to/root/proto/src   # 只给台子用
```

### 3. 只凭证明验证一致性（命题 3 的一半，最强的一条）

```bash
python - <<'PY'
import sys; sys.path.insert(0, "/path/to/root/proto/src")
from uibc_core import tlog
leaves = tlog.build_log([f"sha256:{i:064x}" for i in range(16)])
bad = []
for n in (2,3,4,5,8,13,16):
    for m in range(1, n+1):
        p = tlog.consistency_proof(m, leaves[:n])
        if not tlog.verify_consistency_standalone(m, tlog.mth(leaves[:m]), n, tlog.mth(leaves[:n]), p):
            bad.append((m,n))
print("pairs", 51, "bad", bad)
PY
```
**期望** `pairs 51 bad []`；再把 proof 换成一个 32 字节全零值，必须返回 `False`。

### 3b. 与 SD-JWT（RFC 9901）的 salt 语义是否同构（可跑，不是口头说）

```bash
export UIBC_PRIVACY_ROOT=/path/to/root      # 含 proto/src 与 poc/v06-pkg
python poc/sdjwt_parity.py
```
**期望** `10/10`。它做三件事：两者都"换 salt 必变、公开 salt 可重算"；
**两套承诺格式不可互换**（SD-JWT digest 冒充我方 commit 必须不匹配，反之亦然）；
SD-JWT 绑 claim 名防值移植、我方把 path 绑在树索引。

这条的意义是：我们说"和 RFC 9901 同一个构造"，指的是**语义同构**，
不是字节兼容——两份凭证不可能直接互认，别被话术带走。

### 3c. 形态映射（A 级适配器，**不是凭证**）

```bash
python poc/to_sdjwt_shape.py --bundle poc/blind-a --out out/sdjwt_shape.json
```
**期望** `8/8`。它把披露包字段按 SD-JWT VC 的命名摆一遍（`iss`/`iat`/`evidence.commit`/`status`），
同时**故意不含 JWS 三段结构、不含 signature 段**，并在输出里写明
`not_verifiable_by: [SD-JWT VC verifier, OpenID4VP verifier, ISO mDL reader]`。

这不是缺陷，是设计：任何 SD-JWT 验证器**都应该拒绝它**，因为它没有签名。
若有人拿它去"证明兼容"，请直接判定为误用——本包只主张"字段语义可对齐"，不主张"可互认"。

### 4. 披露包 0.5 / 0.6 的接受与拒绝

```bash
cd /path/to/root
python poc/selective_v10.py --build poc/v06-pkg --file files/action-log.txt --out poc/my-bundle
python poc/selective_v10.py --verify poc/my-bundle --purpose capability-verification/1 \
       --policy poc/my-bundle_witness_policy.json
```
**期望**：`"result": "PASS"`，共 17 项检查全 `true`；其中 `status list operator-a/b` 都需 VALID。
再改一个字：把 `poc/my-bundle/*.txt` 内容改成 `tampered` 重跑 → **期望 `FAIL`**。

### 4b. 盲索引（0.7）：同一文件两次展示必须关联不上

```bash
python poc/selective_v11.py --build poc/v06-pkg --file files/action-log.txt --out poc/blind-a
python poc/selective_v11.py --build poc/v06-pkg --file files/action-log.txt --out poc/blind-b
python - <<'PY'
import json
a = json.load(open("poc/blind-a/bundle.json", encoding="utf-8"))
b = json.load(open("poc/blind-b/bundle.json", encoding="utf-8"))
print("schema", a["schema"])
print("commit_a", a["disclosed_entry"]["commit"][:16])
print("commit_b", b["disclosed_entry"]["commit"][:16])
print("same", a["disclosed_entry"]["commit"] == b["disclosed_entry"]["commit"])
print("has_content_hash", "content_hash" in a["disclosed_entry"])
print("roots_same", a["context"]["salted_root"] == b["context"]["salted_root"])
PY
```
**期望**：`schema uibc-selective-bundle/0.7`、两个 commit 不同、`same False`、`has_content_hash False`、`roots_same False`。
再各自 `--verify`（带 `--policy <目录名>_witness_policy.json`）必须都 `PASS`。
这条的判据是"三件事同时成立"：功能没被换掉、承诺不同、哈希没泄露——少一件就不算闭合。

### 5. 台子场景组（命题 3 的全量）

把 `harness/s11_privacy_disclosure.py` 放进你的 `uibc-bench/harness/`，然后：

```bash
cd uibc-bench
python run.py --only s11 --subject /path/to/root/proto/src
```
**期望**：`PASS 15 / REFERENCE 2 / FAIL 0`，`相对基线 回归 0`（首次跑显示"新增 16"属正常）。
`REFERENCE` 两条分别是「内容哈希可关联」「耗时读数」——**不是通过**，是如实记录。

### 5b. 双运营方见证：跨进程 2-of-3（可跑）

```bash
python poc/dual_operator_witness.py run --src ./src --package poc/v06-pkg --out out
```

**期望**：`verdict: PASS`；`independence: True`（两个运营方 PID 不同、密钥目录不同、公钥不同）；
六条 `negative ... -> PASS(refused)` 全部为拒。

判据按 `expected/dual_operator.expected.json` 的 `must_hold` 与 `negative_keys` 比对，**不要比对 pid**（每次运行都不同）。

边界必须一起读：两个运营方跑在**同一台机器**上，是模拟，不是接入第三方；第三家 `wt-c` 只列入策略、不出签，用来证明 k-of-n 不必全签。产物里的 `honest_caveat` 写明了这三点。

## 判定表

| 命题 | 通过条件 | 不通过时怎么记 |
|---|---|---|
| 1 干净应用 | `git apply --check` exit=0 | 记 HEAD + 报错原文；不算通过 |
| 2 旧包不回归 | 仓库自带 36 例套件仍 36 passed / 30 refused | 记具体失败用例号 |
| 3 披露层 | 步骤 3 全过 + 步骤 4 PASS/篡改 FAIL + 步骤 4b 三条同时成立 + 步骤 5 14 PASS + 步骤 5b PASS | 记哪一条、哪一项检查 false |

## 失败诊断（先看这三条）

1. `ModuleNotFoundError: uibc_core` → `UIBC_PRIVACY_ROOT/proto/src` 没建好，或驱动脚本找错路径；**不要**用 pip 装的那个同名包顶替。
2. `策略摘要不符` → `--policy` 指错文件；每个 bundle 目录旁边有一份 `<bundle目录名>_witness_policy.json`。
3. `PermissionError [WinError 10013]`（Windows）→ 端口绑定被环境拒绝，与本包无关；换端口或换机器。

### 一条已知无害告警

`git apply` 会打印 `new blank line at EOF.` 与 `warning: 1 line adds whitespace errors.`——
这是补丁文件末尾多一个空行造成的 diff 格式提示，**落地内容不受影响**（exit=0，36 例套件不回归）。
若你的仓库开了 pre-commit 的空白检查，可在应用前用 `git apply --whitespace=nowarn`，但请把这条写进你的记录里。

## 边界（请连这句一起引用）

本包是**自测的复跑说明**，由作者提供；跑通它证明"命题可被第三方独立复算"，
**不构成外部评审结论、不构成标准采纳、不构成合规证明**。若你是评审人，请在记录里写明你的环境与 commit。
