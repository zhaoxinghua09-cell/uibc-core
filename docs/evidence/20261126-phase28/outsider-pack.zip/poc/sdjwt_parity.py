# -*- coding: utf-8 -*-
"""竞品同构实证：SD-JWT（RFC 9901）的 salt 语义 vs 我们 0.7 的盲索引。

目的不是"抄"，是回答一个问题：我们说"和 SD-JWT 同一个构造"，这句话能不能被代码验证？
做法：按 RFC 9901 §5.2.2 的 digest 规则实现一遍最小函数，然后做三组对照：
  1. 两者都满足"salt 参与哈希、验证方用公开 salt 本地重算、换 salt 即失配"；
  2. 两套承诺格式不可互换（跨方案移植必须失败）——这是防止"看着一样其实不能互认"；
  3. 差异点：SD-JWT 用 (salt‖claim_name‖JSON(value)) 的拼接串，我们用
     H(sha256(content)‖salt)，靠树索引绑定 path。
"""
import base64, hashlib, json, pathlib, sys

import os
BASE = pathlib.Path(__file__).resolve().parent.parent
ROOT = pathlib.Path(os.environ.get("UIBC_PRIVACY_ROOT", str(BASE)))
PKGDIR = pathlib.Path(os.environ.get("UIBC_PKG", str(ROOT / "poc" / "v06-pkg")))
sys.path.insert(0, str(ROOT / "proto" / "src"))
from uibc_core import merkle                                   # noqa: E402

SALT_A = bytes.fromhex("00112233445566778899aabbccddeeff")
SALT_B = bytes.fromhex("ffeeddccbbaa99887766554433221100")
CLAIM = ("evidence_kind", "capability-verification")
CONTENT = (PKGDIR / "evidence" / "files" / "action-log.txt").read_bytes()


def b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def sdjwt_digest(salt: bytes, name: str, value) -> str:
    """RFC 9901 §5.2.2：digest = b64u(H(salt ‖ claim_name ‖ JSON(claim_value)))。"""
    payload = salt + name.encode() + json.dumps(value, separators=(",", ":"), ensure_ascii=False).encode()
    return b64u(hashlib.sha256(payload).digest())


def ours(commit_content: bytes, salt: bytes) -> str:
    return merkle.leaf_hash(hashlib.sha256(commit_content).digest() + salt).hex()


cases = []


def add(name, ok, detail=""):
    cases.append({"case": name, "ok": bool(ok), "detail": detail})
    print(("[PASS] " if ok else "[FAIL] ") + name + ("  " + detail if detail else ""))


# 1 语义同构：salt 决定承诺、换 salt 必变、公开 salt 可重算
d_a = sdjwt_digest(SALT_A, *CLAIM)
d_b = sdjwt_digest(SALT_B, *CLAIM)
c_a = ours(CONTENT, SALT_A)
c_b = ours(CONTENT, SALT_B)
add("SD-JWT: 换 salt → digest 变", d_a != d_b)
add("我方: 换 salt → commit 变", c_a != c_b)
add("SD-JWT: 公开 salt 可重算", sdjwt_digest(SALT_A, *CLAIM) == d_a)
add("我方: 公开 salt 可重算", ours(CONTENT, SALT_A) == c_a)

# 2 跨方案移植必须失败（两套格式不可互认）
add("SD-JWT digest 冒充我方 commit → 不匹配",
    d_a != c_a and sdjwt_digest(SALT_A, *CLAIM) != c_a)
add("我方 commit 冒充 SD-JWT digest → 不匹配",
    c_a != d_a and ours(CONTENT, SALT_A) != d_a)

# 3 SD-JWT 绑定 claim 名：同名值不同名 → digest 不同（防"值移植"）
d_renamed = sdjwt_digest(SALT_A, "other_name", CLAIM[1])
add("SD-JWT: 改 claim 名 → digest 变（绑名防值移植）", d_renamed != d_a)
# 我方把 path 绑在树索引（leaf_index 以 path 排序决定），改 path 即换位置
ents = json.loads((PKGDIR / "evidence" / "index.json").read_text(encoding="utf-8"))["entries"]
paths = sorted(e["path"] for e in ents)
add("我方: path 绑在树索引（换 path 即换位置）",
    len(paths) == len(ents) and len(set(paths)) == len(paths), f"{len(paths)} 条路径唯一")

# 4 负例：salt 挪用到另一份内容 → 不匹配
other = (PKGDIR / "evidence" / "files" / "run-summary.txt").read_bytes()
add("我方: A 的 salt 用到另一份内容 → commit 不同", ours(other, SALT_A) != c_a)
add("SD-JWT: A 的 salt 用到另一个值 → digest 不同",
    sdjwt_digest(SALT_A, CLAIM[0], "other-value") != d_a)

passed = sum(1 for c in cases if c["ok"])
(BASE / "out" / "sdjwt_parity.json").parent.mkdir(parents=True, exist_ok=True) or (BASE / "out" / "sdjwt_parity.json").write_text(json.dumps(
    {"passed": passed, "total": len(cases), "cases": cases,
     "sdjwt_digest_example": d_a[:24] + "…", "our_commit_example": c_a[:24] + "…",
     "note": "两套都是 salt-binding 承诺；格式不可互换，只共享语义，不共享字节"},
    ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\n{passed}/{len(cases)}")
sys.exit(0 if passed == len(cases) else 1)
