#!/usr/bin/env python3
"""selective_v09.py — 披露包 0.5：离线一致性验证 + 双运营方状态列表。

相对 0.4：
  1. headlog 不再交出全部历史 head，只给 old_root/new_root/proof —— 验证方用
     RFC 6962 独立验证器（不需要条目）完成一致性校验；
  2. new_root 进入 context 并由发证方签名，防止临时编造一对 (old_root,new_root)；
  3. 撤销改用两张独立运营方的状态列表，任一张 REVOKED 即 FAIL（防单方隐瞒）。

用法：
  python selective_v09.py --build poc/v06-pkg --file files/action-log.txt --out DIR [--revoked]
  python selective_v09.py --verify DIR --purpose capability-verification/1 [--expect-old-root HEX]
"""
import argparse, base64, hashlib, json, pathlib, sys, time
BASE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parent / "proto" / "src"))
from uibc_core import (signing, merkle, status_list, tlog, witness,   # noqa: E402
                       witness_registry)

MAX_AGE_S = 24 * 3600
LIST_BITS = 131072   # W3C Bitstring Status List v1.0 最低 131,072 位（16 KB），单表太小等于没隐私
MY_INDEX = 7
WITNESSES, QUORUM = 5, 3
HISTORY = 4


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def _pub(seed):
    return base64.b64encode(signing.ed_public_key(seed)).decode()


def build(pkg, rel, out, purpose, revoked=False):
    pkg = pathlib.Path(pkg); out = pathlib.Path(out); out.mkdir(parents=True, exist_ok=True)
    identity = json.loads((pkg / "identity.json").read_text(encoding="utf-8"))
    manifest = json.loads((pkg / "manifest.json").read_text(encoding="utf-8"))
    lifecycle = json.loads((pkg / "lifecycle.json").read_text(encoding="utf-8"))
    seal = json.loads((pkg / "signatures" / "seal.json").read_text(encoding="utf-8"))
    index = json.loads((pkg / "evidence" / "index.json").read_text(encoding="utf-8"))

    entry = next(e for e in index["entries"] if e["path"] == rel or e["path"].endswith(rel))
    src = pkg / "evidence" / entry["path"]
    if sha(src) != entry["content_hash"]:
        raise SystemExit("source does not match declared hash")
    order = sorted(e["content_hash"] for e in index["entries"])
    leaves = [merkle.leaf_hash(bytes.fromhex(h)) for h in order]
    pos = order.index(entry["content_hash"])
    mproof = merkle.build_proof(leaves, pos)

    now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    issuer_seed = signing.ed_generate_seed()

    # append-only 日志：4 个历史 head + 当前；只导出根与证明
    hist = [hashlib.sha256(f"past-{i}".encode()).hexdigest() for i in range(HISTORY)]
    heads = hist + [manifest["checkpoint_head"]]
    hl = tlog.build_log(heads)
    old_size, new_size = HISTORY, len(heads)
    old_root = tlog.mth(hl[:old_size]).hex()
    new_root = tlog.mth(hl).hex()
    cons = [h.hex() for h in tlog.consistency_proof(old_size, hl)]

    context = {"purpose": purpose, "issued_at": now, "verifier_id": "verifier-demo",
               "nonce": hashlib.sha256((purpose + now + str(time.time_ns())).encode()).hexdigest()[:32],
               "head_root": new_root}
    ctx_sig = signing.context_sign(issuer_seed, seal["signature"], context)

    # 两张独立运营方状态列表
    lists = []
    for op in ("operator-a", "operator-b"):
        bits = status_list.empty(LIST_BITS)
        if revoked:
            status_list.set_status(bits, MY_INDEX, status_list.REVOKED)
        lists.append({"operator": op,
                      "list": status_list.build_token(bits, signing.ed_generate_seed(), op, now),
                      "index": MY_INDEX})

    wseeds = [signing.ed_generate_seed() for _ in range(WITNESSES)]
    policy = {"schema": "uibc-witness-policy/0.1", "name": "demo-policy", "quorum": QUORUM,
              "witnesses": [{"id": f"w{i+1}", "public_key": _pub(s)} for i, s in enumerate(wseeds)]}
    (out.parent / (out.name + "_witness_policy.json")).write_text(
        json.dumps(policy, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    cosigs = [witness.cosign(manifest["checkpoint_head"], s, f"w{i+1}") for i, s in enumerate(wseeds[:4])]

    b = {"schema": "uibc-selective-bundle/0.5",
         "identity": identity, "manifest": manifest, "lifecycle": lifecycle,
         "seal": {k: seal[k] for k in ("public_key", "signature", "key_id", "algorithm")},
         "context": context,
         "ctx_sig": {"signature": ctx_sig, "public_key": _pub(issuer_seed)},
         "witness": {"policy_id": policy["name"],
                     "policy_digest": "sha256:" + hashlib.sha256(
                         json.dumps(policy, ensure_ascii=False, indent=2, sort_keys=True).encode()).hexdigest(),
                     "cosignatures": cosigs},
         "headlog": {"old_size": old_size, "new_size": new_size, "old_root": old_root,
                     "new_root": new_root, "proof": cons},
         "status": {"lists": lists},
         "disclosed_entry": {"path": entry["path"], "type": entry["type"],
                             "content_hash": entry["content_hash"],
                             "media_type": entry.get("media_type")},
         "proof": {"leaf_index": pos, "tree_size": len(order), "siblings": mproof},
         "disclosed_path": entry["path"]}
    (out / "bundle.json").write_text(json.dumps(b, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / entry["path"].replace("/", "_")).write_bytes(src.read_bytes())
    print(json.dumps({"bytes": sum(f.stat().st_size for f in out.iterdir() if f.is_file()),
                      "headlog": {"old": old_size, "new": new_size, "proof_items": len(cons)},
                      "status_lists": len(lists)}, ensure_ascii=False))
    return out


def _age(ts):
    import datetime as dt
    return time.time() - dt.datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ").replace(
        tzinfo=dt.timezone.utc).timestamp()


def verify(bdir, purpose, state_path=None, policy_path=None, expect_old_root=None):
    bdir = pathlib.Path(bdir)
    b = json.loads((bdir / "bundle.json").read_text(encoding="utf-8"))
    checks, fatal = [], False

    def rec(name, ok, detail="", hard=True):
        nonlocal fatal
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        if hard and not ok:
            fatal = True

    def safe(name, fn, hard=True):
        """Malformed input must FAIL, never crash the verifier."""
        try:
            res = fn()
        except Exception as e:                      # noqa: BLE001
            rec(name, False, f"exception: {type(e).__name__}: {e}", hard)
            return None
        rec(name, res if isinstance(res, bool) else True, "" if isinstance(res, bool) else str(res), hard)
        return res

    seal = b["seal"]
    rec("seal signature", signing.ed_seal_verify(
        signing.b64decode_strict(seal["public_key"]), b["identity"], b["manifest"],
        seal["signature"], b["lifecycle"]))
    ctx = b["context"]
    rec("context bound to seal (incl. head_root)", signing.context_verify(
        signing.b64decode_strict(b["ctx_sig"]["public_key"]), seal["signature"], ctx,
        b["ctx_sig"]["signature"]))
    rec("purpose matches", ctx["purpose"] == purpose, ctx["purpose"])

    polp = pathlib.Path(policy_path) if policy_path else bdir.parent / (bdir.name + "_witness_policy.json")
    pol = witness_registry.load_policy(json.loads(polp.read_text(encoding="utf-8")))
    pol_digest = "sha256:" + hashlib.sha256(
        json.dumps(pol, ensure_ascii=False, indent=2, sort_keys=True).encode()).hexdigest()
    rec("trusted policy digest", pol_digest == b["witness"]["policy_digest"])
    okq, info = witness_registry.verify_quorum(pol, b["witness"]["cosignatures"],
                                               b["manifest"]["checkpoint_head"], seal["public_key"])
    rec("witness quorum", okq, f"{len(info['valid'])}/{info['quorum']}")

    # 离线一致性：不需要条目
    hl = b["headlog"]
    rec("new_root bound to context", ctx.get("head_root") == hl["new_root"])
    ok_c = tlog.verify_consistency_standalone(hl["old_size"], bytes.fromhex(hl["old_root"]),
                                              hl["new_size"], bytes.fromhex(hl["new_root"]),
                                              [bytes.fromhex(x) for x in hl["proof"]])
    rec("consistency proof (standalone, no entries)", ok_c,
        f"{hl['old_size']}->{hl['new_size']}")
    if expect_old_root:
        rec("old root matches pinned expectation", hl["old_root"] == expect_old_root,
            f"pinned={expect_old_root[:16]}…")

    # 两张状态列表都要 VALID
    ops = {i.get("operator") for i in b["status"]["lists"]}
    rec("two independent status operators present", len(ops) >= 2 and None not in ops, str(sorted(ops)))
    for item in b["status"]["lists"]:
        op = item.get("operator", "?")
        tok = item["list"]

        def _sig(tok=tok):
            ok_tok, why = status_list.verify_token(tok)
            if not ok_tok:
                rec(f"status list {op} signature", False, why)
                return False
            return True
        if not safe(f"status list {op} signature", _sig):
            continue
        bits = safe(f"status list {op} decode", lambda tok=tok: status_list.bits_of(tok))
        idx = item["index"]
        rec(f"status list {op} index in range", isinstance(idx, int) and 0 <= idx < len(bits) * 8
            if bits is not None else False, f"index={idx}")
        if bits is not None and isinstance(idx, int):
            st = safe(f"status read at {op}", lambda: status_list.get_status(bits, idx))
            if st is not None:
                rec(f"status VALID at {op}", st == status_list.VALID, f"status={st}")

    ent = b["disclosed_entry"]; f = bdir / ent["path"].replace("/", "_")
    rec("file matches committed hash", f.is_file() and sha(f) == ent["content_hash"])
    rec("merkle inclusion proof", merkle.verify_inclusion(
        merkle.leaf_hash(bytes.fromhex(ent["content_hash"])),
        b["proof"]["leaf_index"], b["proof"]["tree_size"], b["proof"]["siblings"],
        bytes.fromhex(b["manifest"]["evidence_root"])))

    used = set()
    if state_path and pathlib.Path(state_path).is_file():
        used = set(json.loads(pathlib.Path(state_path).read_text(encoding="utf-8")))
    rec("nonce not replayed", ctx["nonce"] not in used, ctx["nonce"])
    if not fatal and state_path:
        used.add(ctx["nonce"]); pathlib.Path(state_path).write_text(json.dumps(sorted(used)), encoding="utf-8")
    rec("fresh", _age(ctx["issued_at"]) <= MAX_AGE_S, f"age={int(_age(ctx['issued_at']))}s")

    print(json.dumps({"result": "FAIL" if fatal else "PASS", "checks": checks}, ensure_ascii=False, indent=1))
    return 1 if fatal else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--build"); ap.add_argument("--file"); ap.add_argument("--out")
    ap.add_argument("--verify"); ap.add_argument("--purpose", default="capability-verification/1")
    ap.add_argument("--state"); ap.add_argument("--policy"); ap.add_argument("--expect-old-root")
    ap.add_argument("--revoked", action="store_true")
    a = ap.parse_args()
    if a.build:
        build(a.build, a.file, a.out, a.purpose, a.revoked)
    elif a.verify:
        sys.exit(verify(a.verify, a.purpose, a.state, a.policy, a.expect_old_root))
