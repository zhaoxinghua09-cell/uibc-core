# -*- coding: utf-8 -*-
"""隐私保护验证与选择性披露：披露包 0.6 的接受/拒绝矩阵，跑在实测台上。

被测对象
  REPO   = UIBC_SUBJECT（默认由 run.py 传入），必须是包含 uibc_core 增强副本的目录
  PRIVACY= UIBC_PRIVACY_ROOT（默认 D:\\lgd-work\\phase28-20261125）
          其中 poc/selective_v09.py（0.5）与 poc/selective_v10.py（0.6）是披露包驱动

来源守卫（照 s10 的规矩，不测别人的代码）
  1) REPO 必须存在；
  2) PRIVACY/proto/src 必须是 REPO 本身（同一路径），否则 ABORT——
     披露包脚本内部把它们自己的 proto/src 放进 sys.path，指错了就等于测另一份代码。

判定词义
  PASS     行为符合预期（该过的过、该拒的拒）
  FAIL     行为与预期不符（这就是缺陷）
  REFERENCE 只记录事实、不当成通过：内容级关联、耗时读数

边界：全部为合成 fixture；本组不外发、不部署、不修改任何仓库。
"""
import json, os, shutil, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
KIT = os.path.dirname(HERE)
REPO = os.environ.get("UIBC_SUBJECT") or os.path.join(KIT, "uibc-core-public")
PRIVACY = os.environ.get("UIBC_PRIVACY_ROOT") or r"D:\lgd-work\phase28-20261125"
RESULTS = []

POC = os.path.join(PRIVACY, "poc")
_proto = os.path.abspath(os.path.join(PRIVACY, "proto", "src"))


def _blocked(msg):
    """缺前置就记 BLOCKED（台子语义：缺前置不算失败），不冒充通过。"""
    RESULTS.append(dict(case="B0 隐私披露组前置", verdict="BLOCKED", note=msg, extra={}))
    print("[BLOCKED  ] B0 隐私披露组前置              %s" % msg)
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(KIT, "runs", "s11_results.json")
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(RESULTS, fh, ensure_ascii=False, indent=1)
    return 0


if not os.path.isdir(PRIVACY) or not os.path.isdir(POC):
    sys.exit(_blocked("隐私实验台 %s 不存在（设 UIBC_PRIVACY_ROOT）" % PRIVACY))
if not os.path.isdir(os.path.join(_proto, "uibc_core")):
    sys.exit(_blocked("%s 下没有 uibc_core 包" % _proto))
# 被测对象是"含 v0.6+ 改动的原型副本"，与 --subject（主仓）本就不同：显式声明，不混淆。
print("[INFO     ] S11 被测代码                    %s（披露包原型副本，非 --subject 主仓）" % _proto)

PY = sys.executable
PKG = os.path.join(POC, "v06-pkg")
VERIFY_BUDGET_MS = 600   # 端到端（含解释器启动）预算；理由见 P15 注释与场景清单 11.15


def rec(case, verdict, note="", extra=None):
    RESULTS.append(dict(case=case, verdict=verdict, note=note, extra=extra or {}))
    print("[%-9s] %-30s %s" % (verdict, case, note))


def build(out, script="selective_v10.py", revoked=False):
    cmd = [PY, os.path.join(POC, script), "--build", PKG, "--file",
           "files/action-log.txt", "--out", out]
    if revoked:
        cmd.append("--revoked")
    r = subprocess.run(cmd, cwd=PRIVACY, capture_output=True, text=True)
    if r.returncode != 0:
        rec("build %s" % os.path.basename(out), "FAIL", (r.stderr or r.stdout)[-160:])
        return None
    return json.loads(r.stdout)


def verify(bdir, script="selective_v10.py", policy=None, state=None,
           purpose="capability-verification/1", old_root=None):
    pol = policy or os.path.join(os.path.dirname(bdir), os.path.basename(bdir) + "_witness_policy.json")
    cmd = [PY, os.path.join(POC, script), "--verify", bdir, "--purpose", purpose, "--policy", pol]
    if state:
        cmd += ["--state", state]
    if old_root:
        cmd += ["--expect-old-root", old_root]
    r = subprocess.run(cmd, cwd=PRIVACY, capture_output=True, text=True)
    try:
        j = json.loads(r.stdout)
        return j["result"], [c["check"] for c in j["checks"] if not c["ok"]]
    except Exception:
        return "ERR", (r.stderr or r.stdout)[-160:]


def clone(src):
    d = os.path.join(tempfile.mkdtemp(prefix="s11_"), "b")
    shutil.copytree(src, d)
    # 验证方按 "<bundle 目录名>_witness_policy.json" 找信任策略：把被测包的策略
    # 复制到克隆目录同名位置，否则克隆包会因为找不到策略而 ERR（那是脚本缺陷，不是包的缺陷）
    src_pol = os.path.join(os.path.dirname(src), os.path.basename(src) + "_witness_policy.json")
    if os.path.isfile(src_pol):
        shutil.copy2(src_pol, os.path.join(os.path.dirname(d),
                                           os.path.basename(d) + "_witness_policy.json"))
    return d


def mutate(src, fn):
    d = clone(src)
    b = json.load(open(os.path.join(d, "bundle.json"), encoding="utf-8"))
    fn(b)
    json.dump(b, open(os.path.join(d, "bundle.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    return d


def main():
    tmp = tempfile.mkdtemp(prefix="s11_run_")

    # P1 基线：0.6 包必须 PASS
    b6 = os.path.join(tmp, "b6")
    info = build(b6)
    res, why = verify(b6)
    rec("P1 0.6 基线包", "PASS" if res == "PASS" else "FAIL", "verify=%s" % res,
        {"bundle_bytes": (info or {}).get("bytes"), "failed": why})

    # P2 基准 0.5 包也必须 PASS（回归：0.5 未被 0.6 破坏）
    b5 = os.path.join(tmp, "b5")
    build(b5, script="selective_v09.py")
    res5, why5 = verify(b5, script="selective_v09.py")
    rec("P2 0.5 包回归", "PASS" if res5 == "PASS" else "FAIL", "verify=%s" % res5, {"failed": why5})

    # P3 改披露正文
    d = clone(b6)
    f = [x for x in os.listdir(d) if x.endswith(".txt")][0]
    open(os.path.join(d, f), "wb").write(b"tampered-body")
    res, why = verify(d)
    rec("P3 改披露正文", "PASS" if res == "FAIL" else "FAIL", "verify=%s" % res, {"failed": why})

    # P4 用途不符
    d = mutate(b6, lambda b: b["context"].__setitem__("purpose", "other-purpose/9"))
    res, why = verify(d)
    rec("P4 用途不符", "PASS" if res == "FAIL" else "FAIL", "verify=%s" % res, {"failed": why})

    # P5 nonce 重放
    st = os.path.join(tmp, "state.json")
    first, _ = verify(b6, state=st)
    second, why = verify(b6, state=st)
    rec("P5 nonce 重放", "PASS" if first == "PASS" and second == "FAIL" else "FAIL",
        "first=%s second=%s" % (first, second), {"failed": why})

    # P6 凭证过期
    d = mutate(b6, lambda b: b["context"].__setitem__("issued_at", "2026-01-01T00:00:00Z"))
    res, why = verify(d)
    rec("P6 凭证过期", "PASS" if res == "FAIL" else "FAIL", "verify=%s" % res, {"failed": why})

    # P7 双表均 REVOKED
    rb = os.path.join(tmp, "rev")
    build(rb, revoked=True)
    res, why = verify(rb)
    rec("P7 双运营方均撤销", "PASS" if res == "FAIL" else "FAIL", "verify=%s" % res, {"failed": why})

    # P8 只剩一家运营方（防单方隐瞒）
    d = mutate(b6, lambda b: b["status"]["lists"].pop())
    res, why = verify(d)
    rec("P8 单运营方隐瞒", "PASS" if res == "FAIL" else "FAIL", "verify=%s" % res, {"failed": why})

    # P9 一致性证明伪造
    d = mutate(b6, lambda b: b["headlog"].__setitem__("new_root", "11" * 32))
    res, why = verify(d)
    rec("P9 一致性根伪造", "PASS" if res == "FAIL" else "FAIL", "verify=%s" % res, {"failed": why})

    # P10 离线一致性：只凭证明、49 对 (m,n) 全过 + 四类负例全拒
    code = r'''
import json, sys
sys.path.insert(0, r"%s")
from uibc_core import tlog
heads=[f"sha256:{i:064x}" for i in range(16)]
leaves=tlog.build_log(heads)
bad=[]
n_list=(2,3,4,5,8,13,16)
for n in n_list:
    for m in range(1,n+1):
        p=tlog.consistency_proof(m,leaves[:n])
        ok=tlog.verify_consistency_standalone(m,tlog.mth(leaves[:m]),n,tlog.mth(leaves[:n]),p)
        if not ok: bad.append([m,n])
print(json.dumps({"pairs":sum(len(range(1,n+1)) for n in n_list),"bad":bad,
"forged":tlog.verify_consistency_standalone(4,tlog.mth(leaves[:4]),8,tlog.mth(leaves[:8]),[b"\x00"*32]),
"bad_old":tlog.verify_consistency_standalone(4,b"\x00"*32,8,tlog.mth(leaves[:8]),tlog.consistency_proof(4,leaves[:8])),
"bad_new":tlog.verify_consistency_standalone(4,tlog.mth(leaves[:4]),8,b"\x00"*32,tlog.consistency_proof(4,leaves[:8])),
"empty":tlog.verify_consistency_standalone(4,tlog.mth(leaves[:4]),8,tlog.mth(leaves[:8]),[])}))
''' % _proto.replace("\\", "\\\\")
    r = subprocess.run([PY, "-c", code], cwd=PRIVACY, capture_output=True, text=True)
    try:
        j = json.loads(r.stdout.strip().splitlines()[-1])
        ok = (not j["bad"] and j["forged"] is False and j["bad_old"] is False
              and j["bad_new"] is False and j["empty"] is False)
        rec("P10 离线一致性验证器", "PASS" if ok else "FAIL",
            "%d 对全过、四类伪造全拒" % j["pairs"], j)
    except Exception:
        rec("P10 离线一致性验证器", "FAIL", (r.stderr or r.stdout)[-160:])

    # P11 同内容两次展示：根不同（不可用根关联）
    b6b = os.path.join(tmp, "b6b")
    build(b6b)
    ra = json.load(open(os.path.join(b6, "bundle.json"), encoding="utf-8"))["context"]
    rb2 = json.load(open(os.path.join(b6b, "bundle.json"), encoding="utf-8"))["context"]
    diff_root = ra["salted_root"] != rb2["salted_root"]
    rec("P11 同内容两包根不同", "PASS" if diff_root else "FAIL",
        "%s vs %s" % (ra["salted_root"][:12], rb2["salted_root"][:12]))

    # P12 内容哈希仍相同 —— 如实记录，不判 PASS
    same_hash = (json.load(open(os.path.join(b6, "bundle.json"), encoding="utf-8"))["disclosed_entry"]["content_hash"]
                 == json.load(open(os.path.join(b6b, "bundle.json"), encoding="utf-8"))["disclosed_entry"]["content_hash"])
    rec("P12 内容哈希可关联", "REFERENCE",
        "content_hash 相同=%s；0.6 默认模式仍可凭内容承诺关联，0.7 盲索引模式已闭合（见 P16）" % same_hash)

    # P13 跨包移植 inclusion 路径
    d = mutate(b6, lambda b: (b["context"].__setitem__("salted_root", rb2["salted_root"]),
                              b["context"].__setitem__("salt", rb2["salt"]),
                              b["proof"].__setitem__("siblings",
                                                     json.load(open(os.path.join(b6b, "bundle.json"), encoding="utf-8"))["proof"]["siblings"])))
    res, why = verify(d)
    rec("P13 跨包移植证明", "PASS" if res == "FAIL" else "FAIL", "verify=%s" % res, {"failed": why})

    # P14 耗时读数（只记录，不当通过）
    ts = []
    for _ in range(7):
        t0 = time.perf_counter()
        verify(b6)
        ts.append((time.perf_counter() - t0) * 1000)
    mean_ms = sum(ts) / len(ts)
    rec("P14 验证耗时（含子进程）", "REFERENCE",
        "mean=%.1f ms（含解释器启动，不能与同进程数字直接比）" % mean_ms)

    # P15 阈值判定：判据是端到端（含解释器启动）≤ 600 ms
    # 阈值来源：本机 7 次采样中位约 190 ms；600 ms 留 3 倍余量，取整便于复跑时一眼判断。
    # 改阈值就是改判据 —— 理由写在此处与 cases/场景清单.md 第十二节 11.15。
    ok_ms = mean_ms <= VERIFY_BUDGET_MS
    rec("P15 验证耗时在预算内", "PASS" if ok_ms else "FAIL",
        "mean=%.1f ms ≤ %.0f ms" % (mean_ms, VERIFY_BUDGET_MS))

    # P16 盲索引（0.7）：同一文件两次展示 → 承诺/根都不同，且披露条目不带明文内容哈希。
    # 判据是"三件事同时成立"：两包 verify 都 PASS（没把功能换掉）、commit 不同、无明文哈希。
    v11 = os.path.join(POC, "selective_v11.py")
    if not os.path.isfile(v11):
        rec("P16 盲索引跨包不可关联", "BLOCKED", "缺 poc/selective_v11.py")
    else:
        ba, bb2 = os.path.join(tmp, "v11a"), os.path.join(tmp, "v11b")
        ia = build(ba, script="selective_v11.py")
        ib = build(bb2, script="selective_v11.py")
        ra2, wa = verify(ba, script="selective_v11.py")
        rb3, wb = verify(bb2, script="selective_v11.py")
        try:
            ent_a = json.load(open(os.path.join(ba, "bundle.json"), encoding="utf-8"))
            ent_b = json.load(open(os.path.join(bb2, "bundle.json"), encoding="utf-8"))
        except Exception as e:                     # noqa: BLE001
            rec("P16 盲索引跨包不可关联", "FAIL", "读包异常 %s" % e)
        else:
            ea, eb = ent_a["disclosed_entry"], ent_b["disclosed_entry"]
            leak = "content_hash" in ea or "content_hash" in eb
            schema_ok = ent_a.get("schema") == "uibc-selective-bundle/0.7"
            ok = bool(ia and ib and schema_ok and ea["commit"] != eb["commit"]
                      and not leak and ra2 == "PASS" and rb3 == "PASS")
            rec("P16 盲索引跨包不可关联", "PASS" if ok else "FAIL",
                "schema=%s commit %s vs %s；明文哈希=%s；verify=%s/%s"
                % (ent_a.get("schema"), ea["commit"][:12], eb["commit"][:12], leak, ra2, rb3),
                {"failed": (wa or []) + (wb or [])})

    # P17 双运营方跨进程共签：见证方拆成两个独立进程 + 各自独立密钥目录 + 独立工作目录，
    # 验证方只持公钥集，2-of-3 判定在无共享状态下成立；六类伪造全部被拒。
    # 判据三条同时成立：verdict=PASS、independence.all_three=true、negative_all_refused=true。
    dw = os.path.join(POC, "dual_operator_witness.py")
    if not os.path.isfile(dw):
        rec("P17 双运营方跨进程共签", "BLOCKED", "缺 poc/dual_operator_witness.py")
    else:
        dout = os.path.join(PRIVACY, "out", "_bench_dual")
        t0 = time.perf_counter()
        cp17 = subprocess.run([PY, dw, "run", "--src", _proto, "--package", PKG, "--out", dout],
                              capture_output=True, text=True, timeout=300)
        ms17 = (time.perf_counter() - t0) * 1000
        try:
            with open(os.path.join(dout, "dual_operator_witness.json"), encoding="utf-8") as fh:
                r17 = json.load(fh)
        except Exception:
            r17 = None
        if not r17:
            rec("P17 双运营方跨进程共签", "FAIL", (cp17.stderr or cp17.stdout)[-120:])
        else:
            ok17 = (cp17.returncode == 0 and r17.get("verdict") == "PASS"
                    and r17["independence"]["all_three"] and r17.get("negative_all_refused"))
            rec("P17 双运营方跨进程共签", "PASS" if ok17 else "FAIL",
                "2-of-3=%s 独立=%s 六反例全拒=%s 耗时=%.0f ms" % (
                    r17["positive"]["quorum_2of3_with_two_signers"],
                    r17["independence"]["all_three"],
                    r17.get("negative_all_refused"), ms17),
                {"pids": [r17["independence"]["operators"]["a"]["pid"],
                          r17["independence"]["operators"]["b"]["pid"]],
                 "negative": r17["negative"]})

    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(KIT, "runs", "s11_results.json")
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(RESULTS, fh, ensure_ascii=False, indent=1)
    v = {}
    for x in RESULTS:
        v[x["verdict"]] = v.get(x["verdict"], 0) + 1
    print("=== 汇总 %s ===" % v)
    bad = [x for x in RESULTS if x["verdict"] == "FAIL"]
    if bad:
        print("缺陷：%s" % ", ".join(x["case"] for x in bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
