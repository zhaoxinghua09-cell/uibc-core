#!/usr/bin/env python3
"""to_sdjwt_shape.py — 互操作 A 级：只做**形态映射**，不重签、不生成 JWT。

用途：把 UIBC 披露包的关键字段按 SD-JWT VC 的**命名与语义**摆一遍，方便对方阅读与比对。
硬边界（写死在输出里，防止被当成凭证）：
  * 不含 JWS 三段结构、不含 `eyJ` 前缀、不含 `signature` 字段；
  * `not_verifiable_by` 明确列出"哪些验证器验不了它"；
  * 不声称兼容，只声称"字段语义可对齐"。

用法：python poc/to_sdjwt_shape.py --bundle poc/v07-bundle-a --out out/sdjwt_shape.json
"""
import argparse, datetime as dt, hashlib, json, pathlib, sys

WARNING = ("本文件是按字段语义做的形态映射，**不是 SD-JWT VC**，不可被 SD-JWT 验证器验签；"
           "不含 JWS 三段结构、不含签名段。仅用于人工比对字段，不得作为凭证使用。")


def epoch(ts: str) -> int:
    return int(dt.datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ").replace(
        tzinfo=dt.timezone.utc).timestamp())


def convert(bdir: pathlib.Path) -> dict:
    b = json.loads((bdir / "bundle.json").read_text(encoding="utf-8"))
    ent, ctx = b["disclosed_entry"], b["context"]
    commit = ent.get("commit") or ent.get("content_hash")
    shape = {
        "format": "uibc-shape-adapter/0.1",
        "warning": WARNING,
        "not_verifiable_by": ["SD-JWT VC verifier", "OpenID4VP verifier", "ISO mDL reader"],
        "source_schema": b["schema"],
        "iss": b["identity"]["agent_id"],
        "iat": epoch(ctx["issued_at"]),
        "issuer_owner": b["identity"].get("owner"),
        "purpose": {"value": ctx["purpose"], "sd_jwt_equivalent": "OpenID4VP `purpose`（属 VP 层，非 VC 字段）"},
        "evidence": {
            "path": ent["path"],
            "media_type": ent.get("media_type"),
            "commit": commit,
            "commit_scheme": ent.get("commit_scheme", "content-hash/legacy"),
            "_sd_position": "SD-JWT 会把本字段的承诺放进 `_sd` 数组，由 Disclosure(salt,name,value) 打开；"
                            "我们的承诺格式不同（H(sha256(content)‖salt) vs b64u(H(salt‖name‖JSON))），"
                            "**不可互换**",
        },
        "integrity": {
            "canonical_root": b["manifest"]["evidence_root"],
            "salted_root": ctx.get("salted_root"),
            "log_head": ctx["head_root"],
            "old_root": b["headlog"]["old_root"],
        },
        "status": {
            "operators": [i.get("operator") for i in b["status"]["lists"]],
            "index": b["status"]["lists"][0].get("index"),
            "bsl_equivalent": "Bitstring Status List 的 `encodedList`+`statusListIndex`；我们的 token 编码不同，需转换器而非直接互认",
        },
        "mapping_notes": [
            "iss ← identity.agent_id（对方用 iss + DID/发行者证书，我们用本地 identity.json）",
            "iat ← issued_at（ISO-8601 → 秒级整数，转换在适配器内完成，不进封条）",
            "evidence.commit ← disclosed_entry.commit（语义 = _sd digest，字节不兼容）",
            "status ← 双运营方位数组（语义 = statusListIndex，编码不同）",
        ],
    }
    return shape


def selftest(shape: dict) -> list:
    raw = json.dumps(shape, ensure_ascii=False)
    checks = [
        ("无 JWS 三段结构（不含 eyJ）", "eyJ" not in raw),
        ("无 signature 字段", '"signature"' not in raw),
        ("带 warning", "warning" in shape and "不是 SD-JWT VC" in shape["warning"]),
        ("列明 not_verifiable_by", isinstance(shape["not_verifiable_by"], list) and len(shape["not_verifiable_by"]) >= 3),
        ("iat 为整数（秒）", isinstance(shape["iat"], int)),
        ("iss 非空", bool(shape["iss"])),
        ("commit 存在", bool(shape["evidence"]["commit"])),
        ("标注 commit 不可互换", "不可互换" in shape["evidence"]["_sd_position"]),
    ]
    return checks


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    shape = convert(pathlib.Path(a.bundle))
    checks = selftest(shape)
    out = pathlib.Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"shape": shape, "selftest": [{"check": c, "ok": ok} for c, ok in checks]},
                              ensure_ascii=False, indent=2), encoding="utf-8")
    for c, ok in checks:
        print(("[PASS] " if ok else "[FAIL] ") + c)
    bad = [c for c, ok in checks if not ok]
    print("shape -> %s  (%d/%d)" % (out, len(checks) - len(bad), len(checks)))
    sys.exit(1 if bad else 0)
