#!/usr/bin/env python3
"""selective_v10.py — 披露包 0.6：可加盐证据树，使披露根不可跨展示关联。

与 0.5 的差别（仅在披露层，manifest 语义不动）：
  * 叶 = H(content_hash ‖ bundle_salt)，根 = 加盐根；
  * context 同时签名 canonical_root（manifest 原根）与 salted_root（本次展示根）；
  * 验证方用 inclusion proof 打到 salted_root，并确认两枚根都被签名；
  * 同一内容两次展示 → 两个不同的 salted_root，无法靠根把两次展示串起来。
诚实边界：disclosed_entry.content_hash 仍是原值，同一文件被同一观察者看到两次
仍可凭内容哈希关联；彻底不可关联需要内容承诺随机化，会破坏 manifest 可复算性。
"""
import argparse, base64, hashlib, json, os, pathlib, sys, time
BASE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parent / "proto" / "src"))
from uibc_core import (signing, merkle, status_list, tlog, witness,   # noqa: E402
                       witness_registry)
import selective_v09 as v09                                            # noqa: E402

MAX_AGE_S = 24 * 3600


def salted_leaves(hashes, salt: bytes):
    return [merkle.leaf_hash(bytes.fromhex(h) + salt) for h in hashes]


def build(pkg, rel, out, purpose, revoked=False):
    pkg = pathlib.Path(pkg); out = pathlib.Path(out); out.mkdir(parents=True, exist_ok=True)
    identity = json.loads((pkg / "identity.json").read_text(encoding="utf-8"))
    manifest = json.loads((pkg / "manifest.json").read_text(encoding="utf-8"))
    lifecycle = json.loads((pkg / "lifecycle.json").read_text(encoding="utf-8"))
    seal = json.loads((pkg / "signatures" / "seal.json").read_text(encoding="utf-8"))
    index = json.loads((pkg / "evidence" / "index.json").read_text(encoding="utf-8"))
    entry = next(e for e in index["entries"] if e["path"] == rel or e["path"].endswith(rel))
    src = pkg / "evidence" / entry["path"]
    if v09.sha(src) != entry["content_hash"]:
        raise SystemExit("source does not match declared hash")

    salt = os.urandom(16)
    order = sorted(e["content_hash"] for e in index["entries"])
    leaves = salted_leaves(order, salt)
    pos = order.index(entry["content_hash"])
    proof = merkle.build_proof(leaves, pos)
    salted_root = merkle.root_hash(leaves).hex()

    now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    issuer_seed = signing.ed_generate_seed()
    hist = [hashlib.sha256(f"past-{i}".encode()).hexdigest() for i in range(v09.HISTORY)]
    heads = hist + [manifest["checkpoint_head"]]
    hl = tlog.build_log(heads)
    old_root = tlog.mth(hl[:v09.HISTORY]).hex()
    new_root = tlog.mth(hl).hex()
    cons = [h.hex() for h in tlog.consistency_proof(v09.HISTORY, hl)]

    context = {"purpose": purpose, "issued_at": now, "verifier_id": "verifier-demo",
               "nonce": hashlib.sha256((purpose + now + str(time.time_ns())).encode()).hexdigest()[:32],
               "head_root": new_root, "root_scheme": "salt-commit/0.1",
               "canonical_root": manifest["evidence_root"],
               "salted_root": salted_root,
               "salt": salt.hex()}
    ctx_sig = signing.context_sign(issuer_seed, seal["signature"], context)

    lists = []
    for op in ("operator-a", "operator-b"):
        bits = status_list.empty(v09.LIST_BITS)
        if revoked:
            status_list.set_status(bits, v09.MY_INDEX, status_list.REVOKED)
        lists.append({"operator": op,
                      "list": status_list.build_token(bits, signing.ed_generate_seed(), op, now),
                      "index": v09.MY_INDEX})

    wseeds = [signing.ed_generate_seed() for _ in range(v09.WITNESSES)]
    policy = {"schema": "uibc-witness-policy/0.1", "name": "demo-policy", "quorum": v09.QUORUM,
              "witnesses": [{"id": f"w{i+1}", "public_key": v09._pub(s)} for i, s in enumerate(wseeds)]}
    (out.parent / (out.name + "_witness_policy.json")).write_text(
        json.dumps(policy, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    cosigs = [witness.cosign(manifest["checkpoint_head"], s, f"w{i+1}") for i, s in enumerate(wseeds[:4])]

    b = {"schema": "uibc-selective-bundle/0.6",
         "identity": identity, "manifest": manifest, "lifecycle": lifecycle,
         "seal": {k: seal[k] for k in ("public_key", "signature", "key_id", "algorithm")},
         "context": context,
         "ctx_sig": {"signature": ctx_sig, "public_key": v09._pub(issuer_seed)},
         "witness": {"policy_id": policy["name"],
                     "policy_digest": "sha256:" + hashlib.sha256(
                         json.dumps(policy, ensure_ascii=False, indent=2, sort_keys=True).encode()).hexdigest(),
                     "cosignatures": cosigs},
         "headlog": {"old_size": v09.HISTORY, "new_size": len(heads), "old_root": old_root,
                     "new_root": new_root, "proof": cons},
         "status": {"lists": lists},
         "disclosed_entry": {"path": entry["path"], "type": entry["type"],
                             "content_hash": entry["content_hash"],
                             "media_type": entry.get("media_type")},
         "proof": {"leaf_index": pos, "tree_size": len(order), "siblings": proof},
         "disclosed_path": entry["path"]}
    (out / "bundle.json").write_text(json.dumps(b, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / entry["path"].replace("/", "_")).write_bytes(src.read_bytes())
    print(json.dumps({"bytes": sum(f.stat().st_size for f in out.iterdir() if f.is_file()),
                      "salted_root": salted_root[:16] + "…", "canonical_root": manifest["evidence_root"][:16] + "…",
                      "proof_items": len(cons), "status_lists": len(lists)}, ensure_ascii=False))
    return out


def verify(bdir, purpose, state_path=None, policy_path=None, expect_old_root=None):
    bdir = pathlib.Path(bdir)
    b = json.loads((bdir / "bundle.json").read_text(encoding="utf-8"))
    checks, fatal = [], False

    def rec(name, ok, detail="", hard=True):
        nonlocal fatal
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        if hard and not ok:
            fatal = True

    def safe(name, fn, hard=True):
        try:
            res = fn()
        except Exception as e:                      # noqa: BLE001
            rec(name, False, f"exception: {type(e).__name__}: {e}", hard)
            return None
        rec(name, res if isinstance(res, bool) else True,
            "" if isinstance(res, bool) else str(res)[:80], hard)
        return res

    seal, ctx = b["seal"], b["context"]
    safe("seal signature", lambda: signing.ed_seal_verify(
        signing.b64decode_strict(seal["public_key"]), b["identity"], b["manifest"],
        seal["signature"], b["lifecycle"]))
    safe("context bound to seal", lambda: signing.context_verify(
        signing.b64decode_strict(b["ctx_sig"]["public_key"]), seal["signature"], ctx,
        b["ctx_sig"]["signature"]))
    rec("purpose matches", ctx["purpose"] == purpose, ctx["purpose"])
    rec("canonical root signed as declared", ctx["canonical_root"] == b["manifest"]["evidence_root"])

    polp = pathlib.Path(policy_path) if policy_path else bdir.parent / (bdir.name + "_witness_policy.json")
    pol = witness_registry.load_policy(json.loads(polp.read_text(encoding="utf-8")))
    pol_digest = "sha256:" + hashlib.sha256(
        json.dumps(pol, ensure_ascii=False, indent=2, sort_keys=True).encode()).hexdigest()
    rec("trusted policy digest", pol_digest == b["witness"]["policy_digest"])
    okq, info = witness_registry.verify_quorum(pol, b["witness"]["cosignatures"],
                                               b["manifest"]["checkpoint_head"], seal["public_key"])
    rec("witness quorum", okq, f"{len(info['valid'])}/{info['quorum']}")

    hl = b["headlog"]
    rec("new_root bound to context", ctx.get("head_root") == hl["new_root"])
    safe("consistency proof (standalone)", lambda: tlog.verify_consistency_standalone(
        hl["old_size"], bytes.fromhex(hl["old_root"]), hl["new_size"],
        bytes.fromhex(hl["new_root"]), [bytes.fromhex(x) for x in hl["proof"]]))
    if expect_old_root:
        rec("old root matches pinned expectation", hl["old_root"] == expect_old_root,
            f"pinned={expect_old_root[:16]}…")

    ops = {i.get("operator") for i in b["status"]["lists"]}
    rec("two independent status operators present", len(ops) >= 2 and None not in ops, str(sorted(ops)))
    for item in b["status"]["lists"]:
        op, tok = item.get("operator", "?"), item["list"]

        def _sig(tok=tok):
            ok_tok, why = status_list.verify_token(tok)
            if not ok_tok:
                rec(f"status list {op} signature", False, why)
                return False
            return True
        if not safe(f"status list {op} signature", _sig):
            continue
        bits = safe(f"status list {op} decode", lambda tok=tok: status_list.bits_of(tok))
        idx = item.get("index")
        rec(f"status list {op} index in range",
            bool(bits is not None and isinstance(idx, int) and 0 <= idx < len(bits) * 8), f"index={idx}")
        if bits is not None and isinstance(idx, int):
            st = safe(f"status read at {op}", lambda: status_list.get_status(bits, idx))
            if st is not None:
                rec(f"status VALID at {op}", st == status_list.VALID, f"status={st}")

    ent = b["disclosed_entry"]
    f = bdir / ent["path"].replace("/", "_")
    rec("file matches committed hash", f.is_file() and v09.sha(f) == ent["content_hash"])
    salt = bytes.fromhex(ctx["salt"])
    leaf = merkle.leaf_hash(bytes.fromhex(ent["content_hash"]) + salt)
    safe("salted inclusion proof", lambda: merkle.verify_inclusion(
        leaf, b["proof"]["leaf_index"], b["proof"]["tree_size"], b["proof"]["siblings"],
        bytes.fromhex(ctx["salted_root"])))

    used = set()
    if state_path and pathlib.Path(state_path).is_file():
        used = set(json.loads(pathlib.Path(state_path).read_text(encoding="utf-8")))
    rec("nonce not replayed", ctx["nonce"] not in used, ctx["nonce"])
    if not fatal and state_path:
        used.add(ctx["nonce"])
        pathlib.Path(state_path).write_text(json.dumps(sorted(used)), encoding="utf-8")
    rec("fresh", v09._age(ctx["issued_at"]) <= MAX_AGE_S, f"age={int(v09._age(ctx['issued_at']))}s")

    print(json.dumps({"result": "FAIL" if fatal else "PASS", "checks": checks},
                     ensure_ascii=False, indent=1))
    return 1 if fatal else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--build"); ap.add_argument("--file"); ap.add_argument("--out")
    ap.add_argument("--verify"); ap.add_argument("--purpose", default="capability-verification/1")
    ap.add_argument("--state"); ap.add_argument("--policy"); ap.add_argument("--expect-old-root")
    ap.add_argument("--revoked", action="store_true")
    a = ap.parse_args()
    if a.build:
        build(a.build, a.file, a.out, a.purpose, a.revoked)
    elif a.verify:
        sys.exit(verify(a.verify, a.purpose, a.state, a.policy, a.expect_old_root))
